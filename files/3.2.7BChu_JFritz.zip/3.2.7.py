'''
Is there a correlation between the influenza vaccine and getting the influenza virus?
Brittanie Chu and Joel Fritz
'''
import matplotlib.pyplot as plt
import os.path
directory = os.path.dirname(os.path.abspath(__file__))
# Build an absolute filename from directory + filename
filename = os.path.join(directory, 'Data.csv')
datafile = open(filename,'r')
data = datafile.readlines()
year = []
vaccine = []
infection = []
for line in data[1:7]:
    year1, infection1, vaccine1 = line.split(',')
    year.append(int(year1))
    infection.append(int(infection1))
    vaccine.append(int(vaccine1))
    
fig, ax = plt.subplots(1, 1)
ax.plot(year, vaccine, '#0000FF')
ax.plot(year, infection, '#FF00FF')
ax.set_title("Vaccine(Blue) vs Infection(Pink) in 2012 to 2017")
ax.set_xlabel("Year")
ax.set_ylabel("Frequency (Number of people)")
fig.show()